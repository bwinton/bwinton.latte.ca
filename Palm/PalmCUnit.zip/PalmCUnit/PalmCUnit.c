#include <PalmOS.h>
#include "segments.h"

#include "TestDB.h"
#include "TestRun.h"

#include "PalmCUnitRsc.h"

extern void initialize_suite();
extern void terminate_suite();

static char** groupItems = NULL;
static char** failureItems = NULL;

typedef struct RunnerPrefsStruct {
    UInt8 runTestsOnLaunch : 1;
    UInt8 spare8 : 7;               // 1 byte
    UInt8 otherSpare8;              // 2 bytes
    Int16 suiteToRun;               // 4 bytes
    UInt8 spares8[60];              // 64 bytes
} RunnerPrefsStruct;
RunnerPrefsStruct runnerPrefs, *runnerPrefsPtr;



#define appFileCreator   'UntT'
#define appVersionNum     0x01
#define appPrefID         0x00
#define appPrefVersionNum 0x01
#define appDBType        'DaTa'

#define ourMinVersion  sysMakeROMVersion(2,0,0,sysROMStageRelease,0)
#define kPalmOS10Version  sysMakeROMVersion(1,0,0,sysROMStageRelease,0)
#define minColorVersion  sysMakeROMVersion(3,5,0,sysROMStageRelease,0)


#define PROGBAR_LEFT 10
#define PROGBAR_TOP 20
#define PROGBAR_EXTENT 140 
#define PROGBAR_HEIGHT 3

#define SetCheckState(x,y) CtlSetValue((ControlType*)FrmGetObjectPtr(frmP,FrmGetObjectIndex(frmP,(x))),(y))
#define GetCheckState(x) CtlGetValue((ControlType*)FrmGetObjectPtr(frmP,FrmGetObjectIndex(frmP,(x))))



static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
  UInt32 romVersion;
  FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
  if ( romVersion < requiredVersion ) {
    if ( (launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
      (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp) ) {
      FrmAlert (RomIncompatibleAlert);
      if ( romVersion <= kPalmOS10Version ) {
        AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
      }
    }
    return sysErrRomIncompatible;
  }
  return errNone;
}


static void CreateEmptyPreferencesDB(void) {
    UInt16 recIndex;
    MemHandle recH;
    Err er;
    DmOpenRef prefsDB=0;
    
    er = DmCreateDatabase(0, "TestRunnerDB", appFileCreator, appDBType, false);
 
    prefsDB = DmOpenDatabaseByTypeCreator(appDBType,appFileCreator,dmModeReadWrite);

    recIndex = 0;
    recH = DmNewRecord(prefsDB,&recIndex,sizeof(runnerPrefs));

    MemSet(&runnerPrefs,sizeof(runnerPrefs),0);
    
   if (recH) {
      runnerPrefsPtr = (RunnerPrefsStruct*)MemHandleLock(recH);

      DmWrite(runnerPrefsPtr,0,&runnerPrefs,sizeof(runnerPrefs));
      MemHandleUnlock(recH);
      DmReleaseRecord(prefsDB,0,true);
   }
   
   DmCloseDatabase(prefsDB);
}


static void WritePreferencesToDB(void) {
   Err er;
   MemHandle h;
       DmOpenRef prefsDB=0;

      // attempt to open the database
      prefsDB = DmOpenDatabaseByTypeCreator(appDBType, appFileCreator, 
                                              dmModeReadWrite);
   
      // if the database does not exist create it
      if (prefsDB == 0) {
         er = DmGetLastErr();
         if (er == dmErrCantFind) {
            CreateEmptyPreferencesDB();
            prefsDB = DmOpenDatabaseByTypeCreator(appDBType, appFileCreator, dmModeReadWrite);
         }
        }

   if (prefsDB) {
      h = DmGetRecord(prefsDB, 0);

      if (h) {
         runnerPrefsPtr = (RunnerPrefsStruct*)MemHandleLock(h);
               
        DmWrite(runnerPrefsPtr,0,&runnerPrefs,sizeof(runnerPrefs));
      
          MemHandleUnlock(h);
    
          DmReleaseRecord(prefsDB, 0, true);
      }
      
      DmCloseDatabase(prefsDB);
   }
}



static void GetPreferencesFromDB(void) {
   Err er;
   MemHandle h;
       DmOpenRef prefsDB=0;

      // attempt to open the database
      prefsDB = DmOpenDatabaseByTypeCreator(appDBType, appFileCreator, 
                                              dmModeReadWrite);
   
      // if the database does not exist create it
      if (0 == prefsDB) {
         er = DmGetLastErr();
         if (er == dmErrCantFind) {
            CreateEmptyPreferencesDB();
            prefsDB = DmOpenDatabaseByTypeCreator(appDBType, appFileCreator, dmModeReadWrite);
         }
        }

   if (prefsDB) {
      // get a db handle to read from
      h = DmGetRecord(prefsDB, 0);

      if (h) {
         runnerPrefsPtr = (RunnerPrefsStruct*)MemHandleLock(h);
         
         MemMove(&runnerPrefs,runnerPrefsPtr,sizeof(runnerPrefs));
         
          MemHandleUnlock(h);
    
          DmReleaseRecord(prefsDB, 0, true);
    
          DmCloseDatabase(prefsDB);
      }
   }
}


static void* GetObjectPtr(UInt16 objectID)
{
  FormPtr frmP = FrmGetActiveForm();
  return FrmGetObjectPtr(frmP, FrmGetObjectIndex(frmP, objectID));
}

static void setTextToField(FieldType* fld, const Char* str)
{
   MemHandle txtH = MemHandleNew(StrLen(str) + 1);
   MemHandle oldTxtH = (MemHandle)FldGetTextHandle(fld);
   ErrFatalDisplayIf(!txtH, "memory error");
   StrCopy((char *)MemHandleLock(txtH), str);
   MemHandleUnlock(txtH);
   // This memory can't leak, it gets freed by the system when the form is 
   // closed
   FldSetTextHandle(fld, (MemHandle)txtH);
   if ( oldTxtH ) {
     MemHandleFree(oldTxtH);
   }
}

static void setTextToFieldAndDraw(FieldType* fld, const Char* str)
{
   setTextToField(fld, str);
   FldDrawField(fld);
}

static UInt16 runs, haveRun;

static Boolean CanDoColors(void) {
   WinScreenModeOperation winOp=winScreenModeGet;
   UInt32 romVersion, width, height, depth;
   static Boolean retVal=false;
   static Boolean set=false;

   if (! set) {
      FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);

      if (romVersion >= minColorVersion) {
         WinScreenMode(winOp, &width, &height, &depth, &retVal);
      }
      
      set = true;
   }

   return retVal;
}

static void ClearProgressBar(void) {
   RectangleType rect;
   CustomPatternType pattern = {
         0, 0, 0, 0,
         0, 0, 0, 0
   };
   char number[3];
   
   WinSetPattern((const CustomPatternType *)&pattern);
      
   RctSetRectangle(&rect,PROGBAR_LEFT,PROGBAR_TOP,PROGBAR_EXTENT,PROGBAR_HEIGHT);

   WinFillRectangle(&rect,0);
   
   setTextToFieldAndDraw((FieldType*)GetObjectPtr(MainRunsField),StrIToA(number,0));                             
   setTextToFieldAndDraw((FieldType*)GetObjectPtr(MainFailuresField),StrIToA(number,0));
}

static void PaintProgressBar(void) {
   UInt16 x;
   RectangleType rect;
   PTestRegistry reg;
   CustomPatternType colorPattern = {
         0xff, 0xff, 0xff, 0xff,
         0xff, 0xff, 0xff, 0xff
   };
   CustomPatternType bwPassPattern = {
         0x11, 0x11, 0x11, 0x11,
         0x11, 0x11, 0x11, 0x11
   };
   RGBColorType passColor = {
      0,0x00,0xAA,0x00
   };
   RGBColorType failColor = {
      0,0xFF,0x00,0x00
   };
   RGBColorType rgbColor;
   CustomPatternType *bwPattern;
   UInt16 numFails;
   char number[8];
   
   haveRun++;

   if (haveRun > runs)
      haveRun = runs;
   
   if (runs == 0) {
      ClearProgressBar();
      return;
   }
   
   // how many tests have been run out of how many possible?
   x = (UInt16)(PROGBAR_EXTENT * haveRun / runs);

   // draw progress bar
   reg = get_registry();
   
   WinSetDrawWindow(WinGetDisplayWindow());
   
   if (reg->uiNumberOfFailures) {
      rgbColor = failColor;
      bwPattern = &colorPattern;
      
   } else {
      rgbColor = passColor;
      bwPattern = &bwPassPattern;
   }

   if (CanDoColors()) {
      IndexedColorType colorNumber;

      colorNumber = WinRGBToIndex(&rgbColor);
      WinSetForeColor(colorNumber);
      WinSetPattern((const CustomPatternType *)&colorPattern);
        
   } else {
      WinSetPattern((const CustomPatternType *)bwPattern);
   }

   RctSetRectangle(&rect,PROGBAR_LEFT,PROGBAR_TOP,x,PROGBAR_HEIGHT);

   WinFillRectangle(&rect,0);

   setTextToFieldAndDraw((FieldType*)GetObjectPtr(MainRunsField),StrIToA(number,haveRun));
   numFails = reg->uiNumberOfFailures;                               
   setTextToFieldAndDraw((FieldType*)GetObjectPtr(MainFailuresField),StrIToA(number,numFails));
}


static void PaintProgressBarCB(const char* pTest, const char* pGroup, 
                      PTestResult pTestResult) {
   PaintProgressBar();
}

static void MainFormInit(FormPtr frmP)
{
  UInt16        groups;
  int           i = 0;
  TestGroup*    group;
  groups = get_registry()->uiNumberOfGroups + 1;
  groupItems = (char**)MemPtrNew(groups * sizeof(char*));
  groupItems[i++] = "ALL groups";
  for ( group = get_registry()->pGroup; group; group = group->pNext ) {
    groupItems[i++] = group->pName;
  }
  LstSetListChoices((ListType*)GetObjectPtr(MainTestsList), groupItems, groups);
  LstSetHeight((ListType*)GetObjectPtr(MainTestsList), groups > 10 ? 10 : groups);
  
  if ((UInt16)(runnerPrefs.suiteToRun) >= groups) {
    runnerPrefs.suiteToRun = 0;
  }
  
  LstSetSelection((ListType*)GetObjectPtr(MainTestsList), runnerPrefs.suiteToRun);
  CtlSetLabel((ControlType*)GetObjectPtr(MainTestsPopTrigger),
  LstGetSelectionText((ListType*)GetObjectPtr(MainTestsList), runnerPrefs.suiteToRun));

  set_test_complete_handler(PaintProgressBarCB);
}


static Boolean MainFormHandleEvent(EventPtr eventP)
{
  Boolean handled = false;
  FormPtr frmP;
  TestGroup* group;

  switch (eventP->eType) {
  case menuEvent:
    if ( eventP->data.menu.itemID == MainOptionsAboutCUnit ) {
      MenuEraseStatus(0);
      FrmAlert(AboutForm);
      handled = true;
    }
    
    if ( eventP->data.menu.itemID == MainOptionsPrefs ) {
      MenuEraseStatus(0);
      frmP = FrmInitForm(PreferencesForm);
      
        SetCheckState(RunTestsCheck,runnerPrefs.runTestsOnLaunch);      
      
      FrmDoDialog(frmP);
      
          runnerPrefs.runTestsOnLaunch = GetCheckState(RunTestsCheck);
      
      FrmDeleteForm(frmP);
      
      WritePreferencesToDB();
      
      handled = true;
    }
    break;

  case frmOpenEvent:
    frmP = FrmGetActiveForm();
    MainFormInit( frmP);
    FrmDrawForm ( frmP);
    handled = true;
    break;
      
  case frmUpdateEvent:
    PaintProgressBar();
    break;

  case ctlSelectEvent:
    if ( eventP->data.ctlSelect.controlID == MainRunButton ) {
      char number[8];
      int i = 0;
      UInt16 failures = 0;                            
      TestResult* result;
      runs = 0;
      haveRun = 0;
      ClearProgressBar();
      runnerPrefs.suiteToRun = LstGetSelection((ListType*)GetObjectPtr(MainTestsList));
      if ( LstGetSelection((ListType*)GetObjectPtr(MainTestsList)) == 0 ) {
        runs = get_registry()->uiNumberOfTests;
        run_all_tests();
      } else {
        for ( group = get_registry()->pGroup; group; group = group->pNext ) {
          if ( group->pName == LstGetSelectionText((ListType*)GetObjectPtr(MainTestsList), LstGetSelection((ListType*)GetObjectPtr(MainTestsList)) ) ) {
            runs = group->uiNumberOfTests;
            run_group_tests(group);
            break;
          }
        }
      }
      setTextToFieldAndDraw((FieldType*)GetObjectPtr(MainRunsField),StrIToA(number,runs));
      failures = get_registry()->uiNumberOfFailures;                               
      setTextToFieldAndDraw((FieldType*)GetObjectPtr(MainFailuresField),StrIToA(number,failures));
      if ( failureItems == 0 ) {
        failureItems = (char**)MemPtrNew(failures * sizeof(Char*));
      } else if ( MemPtrSize(failureItems) < failures * sizeof(Char*) ) {
        MemPtrFree(failureItems);
        failureItems = (char**)MemPtrNew(failures * sizeof(Char*));
      }
      for ( result = get_registry()->pResult; result; result = result->pNext) 
        failureItems[i++] = result->strCondition;
        LstSetListChoices((ListType*)GetObjectPtr(MainFailuresList), failureItems, failures);
        LstDrawList((ListType*)GetObjectPtr(MainFailuresList));
        handled = true;
      }
      break;

  case lstSelectEvent:
    if ( eventP->data.lstSelect.listID == MainFailuresList ) {
      char line[8];
      int n = eventP->data.lstSelect.selection;
      FormType* form = FrmInitForm(FailureForm);
      TestResult* result = get_registry()->pResult;
      while ( n-- ) {
        result = result->pNext; 
      }
      setTextToField((FieldType*)FrmGetObjectPtr(form, FrmGetObjectIndex(form, FailureGroupField)), result->pTestGroup->pName);
      setTextToField((FieldType*)FrmGetObjectPtr(form, FrmGetObjectIndex(form, FailureTestField)), result->pTestCase->pName);
      setTextToField((FieldType*)FrmGetObjectPtr(form, FrmGetObjectIndex(form, FailureFileField)), result->strFileName);
      setTextToField((FieldType*)FrmGetObjectPtr(form, FrmGetObjectIndex(form, FailureLineField)), StrIToA(line,result->uiLineNumber));
      setTextToField((FieldType*)FrmGetObjectPtr(form, FrmGetObjectIndex(form, FailureConditionField)), result->strCondition);
      FrmDoDialog(form);
      FrmDeleteForm(form);
      handled = true;
    }
    break;

  case frmCloseEvent:
      if (groupItems) MemPtrFree(groupItems);
      if (failureItems) MemPtrFree(failureItems);
      handled = false;
    break;

  default:
    break;
    
  }
  
  return handled;
}


static Boolean AppHandleEvent(EventPtr eventP)
{
  FormPtr frmP;
  if (eventP->eType == frmLoadEvent) {
    frmP = FrmInitForm(eventP->data.frmLoad.formID);
    FrmSetActiveForm(frmP);
    if ( eventP->data.frmLoad.formID == MainForm ) {
      FrmSetEventHandler(frmP, MainFormHandleEvent);
      return true;
    }
  }
  return false;
}

UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
  EventType ev;

  Err error = RomVersionCompatible (ourMinVersion, launchFlags);
  if ( error ) {
    return error;
  }

  switch ( cmd ) {
    case sysAppLaunchCmdNormalLaunch: {
      EventType event;
      initialize_registry();
      initialize_suite();
      GetPreferencesFromDB();
      
      FrmGotoForm(MainForm);

      if (runnerPrefs.runTestsOnLaunch) {
        MemSet(&ev,sizeof(EventType),0);
        ev.eType = ctlSelectEvent;
        ev.data.ctlSelect.controlID = MainRunButton;
        EvtAddEventToQueue(&ev);
      }       

      do {
        UInt16 error;
        EvtGetEvent(&event, evtWaitForever);
        if ( !SysHandleEvent(&event) ) {
          if ( !MenuHandleEvent(0, &event, &error) ) {
            if ( !AppHandleEvent(&event) ) {
              FrmDispatchEvent(&event);
            }
          }
        }
      } while ( event.eType != appStopEvent );
      }
      FrmCloseAllForms();
      terminate_suite();
      cleanup_registry();
      WritePreferencesToDB();
      break;

    default:
      break;
    }
  return errNone;
}

