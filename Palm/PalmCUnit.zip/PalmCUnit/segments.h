#ifndef __SEGMENTS_H__
#define __SEGMENTS_H__

/* define segments here */
#define FRAMEWORK __attribute__((section("framewrk")))

#endif
