/*
 * TestSuite.c
 */

// Testing Framework includes.
#include "segments.h"
#include "TestDB.h"

// Application includes.
#include "../SimpleStack.h"

namespace test {

/*- Base Test Group -----------*/

namespace base {

int Init( void )
{
    return 0;
}

int Clean( void )
{
    return 0;
}

int TestInit( void )
{
    return 0;
}

int TestClean( void )
{
    return 0;
}


void Int16Equals( void )
{
    Int16 x = 10;
    Int16 y = 10;

    ASSERT( x == y );
}

} // namespace base

/*- Simple Stack Test Group -----------*/

namespace stack {
static SimpleStack* stack;

int Init( void )
{
    return 0;
}

int Clean( void )
{
    return 0;
}

int TestInit( void )
{
    stack = new SimpleStack();
    return 0;
}

int TestClean( void )
{
    delete( stack );
    return 0;
}


void StartsEmpty( void )
{
    ASSERT( stack->empty() );
}

void NotEmpty( void )
{
    SimpleStackItem item( 1, stack );
    stack->push( item );
    ASSERT( !stack->empty() );
}

void TopEquals( void )
{
    SimpleStackItem item( 1, stack );
    stack->push( item );
    ASSERT( stack->getTopItem() == item );
    ASSERT( stack->getTopItem().identifier == item.identifier );
    ASSERT( stack->getTopItem().pointer == item.pointer );
}

void FindOne( void )
{
    UInt16 id = 13;
    SimpleStackItem item( id, stack );
    stack->push( item );
    ASSERT( stack->find( id ) == item );
    ASSERT( stack->find( id ).identifier == item.identifier );
    ASSERT( stack->find( id ).pointer == item.pointer );
}

void setupFind( void )
{
    SimpleStackItem item1( 1, stack );
    SimpleStackItem item2( 2, stack );
    SimpleStackItem item3( 3, stack );
    stack->push( item1 );
    stack->push( item2 );
    stack->push( item3 );
}

void FindTop( void )
{
    setupFind();
    UInt16 id = 1;
    SimpleStackItem item( id, stack );
    ASSERT( stack->find( id ) == item );
    ASSERT( stack->find( id ).identifier == item.identifier );
    ASSERT( stack->find( id ).pointer == item.pointer );
}

void FindMiddle( void )
{
    setupFind();
    UInt16 id = 2;
    SimpleStackItem item( id, stack );
    ASSERT( stack->find( id ) == item );
    ASSERT( stack->find( id ).identifier == item.identifier );
    ASSERT( stack->find( id ).pointer == item.pointer );
}

void FindBottom( void )
{
    setupFind();
    UInt16 id = 3;
    SimpleStackItem item( id, stack );
    ASSERT( stack->find( id ) == item );
    ASSERT( stack->find( id ).identifier == item.identifier );
    ASSERT( stack->find( id ).pointer == item.pointer );
}

void FindDuplicate( void )
{
    setupFind();
    UInt16 duplicateId = 2;
    SimpleStackItem item( duplicateId, &duplicateId );
    ASSERT( stack->find( duplicateId ) == item );
    ASSERT( stack->find( duplicateId ).identifier == item.identifier );
    ASSERT( stack->find( duplicateId ).pointer == item.pointer );
}

} // namespace stack

/*-----------------------------*/

} // namespace test
 
void initialize_suite()
{
    PTestGroup group;
    PTestCase test;

    group = add_test_group( "Base Group",
            test::base::Init, test::base::Clean,
            test::base::TestInit, test::base::TestClean );
    test = add_test_case( group, "Int16 equals", test::base::Int16Equals );

    group = add_test_group( "Simple Stack Group",
            test::stack::Init, test::stack::Clean,
            test::stack::TestInit, test::stack::TestClean );
    test = add_test_case( group, "Starts Empty", test::stack::StartsEmpty );
    test = add_test_case( group, "Not Empty", test::stack::NotEmpty );
    test = add_test_case( group, "Top Equals", test::stack::TopEquals );
    test = add_test_case( group, "Find One", test::stack::FindOne );
    test = add_test_case( group, "Find Top", test::stack::FindTop );
    test = add_test_case( group, "Find Middle", test::stack::FindMiddle );
    test = add_test_case( group, "Find Bottom", test::stack::FindBottom );
    test = add_test_case( group, "Find Duplicate", test::stack::FindDuplicate );
}

void terminate_suite()
{
}
