/*
 *	Contains Type Definitions for some generic functions used across
 *	CUnit project files.
 *
 *	Created By     : Anil Kumar on 13/Oct/2001
 *	Last Modified  : 13/Oct/2001
 *	Comment        : Moved some of the generic functions declarations 
 *	                 from other files to this one so as to use the 
 *	                 functions consitently. This file is not included
 *	                 in the distribution headers because it is used 
 *	                 internally by CUnit.
 *	EMail          : aksaharan@yahoo.com
 *
 */

#ifndef _Util_h_
#define _Util_h_

#include "segments.h"

extern int compare_strings(const char* szSrc, const char* szDest) FRAMEWORK;

extern void trim_left(char* szString) FRAMEWORK;
extern void trim_right(char* szString) FRAMEWORK;
extern void trim(char* szString) FRAMEWORK;

#endif /* _Util_h_ */
