/*
 *	Contains Interface to Run tests.
 *
 *	Created By     : Anil Kumar on ...(in month of Aug 2001)
 *	Last Modified  : 09/Aug/2001
 *	Comment        : Contains generic run tests interface which can be used
 *						be used for any type of frontend interface framework.
 *	EMail          : aksaharan@yahoo.com
 */

#ifndef _TestRun_h_
#define _TestRun_h_

#include "CUnit.h"
#include "Errno.h"
#include "TestDB.h"

/*
 *	Declarations for the Current running group/test case.
 */
extern PTestGroup	g_pTestGroup;
extern PTestCase	g_pTestCase;


/*
 *	Type Defintions for Message Handlers.
 */
typedef void (*TestStartMessageHandler)(const char* pTest, const char* pGroup);
typedef void (*TestCompleteMessageHandler)(const char* pTest, const char* pGroup,
							PTestResult pTestResult);
typedef void (*AllTestsCompleteMessageHandler)(PTestResult pTestResult);

/*
 * Get/Set functions for the Message Handlers.
 */
extern void set_test_start_handler(TestStartMessageHandler pTestStartMessage) FRAMEWORK;
extern void set_test_complete_handler(TestCompleteMessageHandler pTestCompleteMessage) FRAMEWORK;
extern void set_all_test_complete_handler(AllTestsCompleteMessageHandler pAllTestsCompleteMessage) FRAMEWORK;
extern TestStartMessageHandler get_test_start_handler(void) FRAMEWORK;
extern TestCompleteMessageHandler get_test_complete_handler(void) FRAMEWORK;
extern AllTestsCompleteMessageHandler get_all_test_complete_handler(void) FRAMEWORK;

/*
 * Function to Run all the Registered tests under various groups
 */
extern int run_all_tests(void) FRAMEWORK;
extern int run_group_tests(PTestGroup pGroup) FRAMEWORK;
extern int run_test(PTestGroup pGroup, PTestCase pTest) FRAMEWORK;

extern int get_number_of_groups_run(void) FRAMEWORK;
extern int get_number_of_tests_run(void) FRAMEWORK;


#endif  /*  _TestRun_h_  */
