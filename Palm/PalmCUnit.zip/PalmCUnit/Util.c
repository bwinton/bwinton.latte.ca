/*
 *	Contains some generic functions used across CUnit project files.
 *
 *	Created By     : Anil Kumar on 13/Oct/2001
 *	Last Modified  : 13/Oct/2001
 *	Comment        : Moved some of the generic functions definitions 
 *	                 from other files to this one so as to use the 
 *	                 functions consitently. This file is not included
 *	                 in the distribution headers because it is used 
 *	                 internally by CUnit.
 *	EMail          : aksaharan@yahoo.com
 *
 */
#include <PalmOS.h>
#include "segments.h"

#if 0
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <assert.h>
#include <string.h>
#endif

#include "Util.h"


int compare_strings(const char* szSrc, const char* szDest)
{

  return StrCaselessCompare(szSrc, szDest);
/*
	while (*szSrc && *szDest && toupper(*szSrc) == toupper(*szDest)) {
		szSrc++;
		szDest++;
	}
		
	return *szSrc - *szDest;
*/
}

void trim(char* szString)
{
	trim_left(szString);
	trim_right(szString);
}

void trim_left(char* szString)
{
	int nOffset = 0;
	char* szSrc = szString;
	char* szDest = szString;
	
	ErrFatalDisplayIf(szString==0, "trim_lest(0)");

	/* 
	 * Scan for the spaces in the starting of string.
	 */
	for (; *szSrc; szSrc++, nOffset++) {
		if ( *szSrc != ' ' || *szSrc != '\t' )
			break;
	}

	for(; nOffset && (*szDest = *szSrc); szSrc++, szDest++)
		;
	
}

void trim_right(char* szString)
{
	int nLength = 0;
	char* szSrc = szString;
	
	ErrFatalDisplayIf(szString==0, "trim_right(0)");

	nLength = StrLen(szString);
	/*
	 * Scan for specs in the end of string.
	 */
	for (; nLength && ( *(szSrc+nLength-1) == ' ' || *(szSrc+nLength-1) == '\t' ); nLength--)
		;

	*(szSrc + nLength) = '\0';
}
