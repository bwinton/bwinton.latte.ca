/*
 *	Contains ASSERT implementation which handles the assert.
 *	If logs if the Condition is false else it ignores it.
 *
 *	Created By     : Anil Kumar on ...(in month of Aug 2001)
 *	Last Modified  : 09/Aug/2001
 *	Comment	       : Added only skeleton function.
 *	Email          : aksaharan@yahoo.com
 *
 *	Last Modified  : 19/Aug/2001
 *	Comment	       : Added add_failure routine call.
 *	Email          : aksaharan@yahoo.com
 *
 */
#include <PalmOS.h>
#include "segments.h"

#if 0
#include <stdio.h>
#endif
#include "TestDB.h"
#include "TestRun.h"
#include "CUnit.h"


/*
void assertImplementation(unsigned int uiValue, char strMessage[],
		char strCondition[], char strFile[], unsigned int uiLine)
{
	add_failure(strMessage, strCondition, strFile, uiLine, g_pTestGroup, g_pTestCase);
}
*/


void assertTrueImplementation(char strMessage[], char strCondition[], 
  char strFile[], unsigned int uiLine)
{
	add_failure(strMessage, strCondition, strFile, uiLine, g_pTestGroup, g_pTestCase);
}

void assertStrEqualImplementation(char strMessage[], char strExp[], 
  char strAct[], char strFile[], unsigned int uiLine)
{
   Char *buf;
   unsigned int len = 0;
   char *strExpLab = "Expected: ";
   char *strActLab = ", but was: ";

   len += StrLen(strExp);
   len += StrLen(strAct);
   len += StrLen(strExpLab);
   len += StrLen(strActLab);
   
   len++;
   
   buf = (Char *)MemPtrNew(len);

   if (buf) {
      StrCopy(buf,strExpLab);
      StrCat(buf,strExp);
      StrCat(buf,strActLab);
      StrCat(buf,strAct);

		add_failure(strMessage, buf, strFile, uiLine, g_pTestGroup, g_pTestCase);
   
      MemPtrFree(buf);
   } else {

   	add_failure(strMessage, NULL, strFile, uiLine, g_pTestGroup, g_pTestCase);
   }
}


void assertInt8EqualImplementation(char strMessage[], Int8 inexp, 
  Int8 inact, char strFile[], unsigned int uiLine, unsigned int u)
{
   Char actual[5];
   Char expected[5];
   Int16 exp;
   Int16 act;
   
   exp = inexp;
   act = inact;

   if (u) {
      exp &= 0xFF;
      act &= 0xFF;

      StrPrintF(expected,"%hu",exp);
      StrPrintF(actual,  "%hu",act);

   } else {

      StrPrintF(expected,"%hd",exp);
      StrPrintF(actual,  "%hd",act);
   }

   assertStrEqualImplementation(strMessage,expected,actual,strFile,uiLine);
}


void assertInt16EqualImplementation(char strMessage[], Int16 exp, 
  Int16 act, char strFile[], unsigned int uiLine, unsigned int u)
{
   Char actual[7];
   Char expected[7];

   if (u) {
      StrPrintF(expected,"%u",exp);
      StrPrintF(actual,  "%u",act);
   } else {
      StrPrintF(expected,"%d",exp);
      StrPrintF(actual,  "%d",act);
   }

   assertStrEqualImplementation(strMessage,expected,actual,strFile,uiLine);
}


void assertInt32EqualImplementation(char strMessage[], Int32 exp, 
  Int32 act, char strFile[], unsigned int uiLine, unsigned int u)
{
   Char actual[12];
   Char expected[12];

   if (u) {
      StrPrintF(expected,"%lu",exp);
      StrPrintF(actual,  "%lu",act);
   } else {
      StrPrintF(expected,"%ld",exp);
      StrPrintF(actual,  "%ld",act);
   }

   assertStrEqualImplementation(strMessage,expected,actual,strFile,uiLine);
}
