/*
 *	Contains ASSERT Macro definition
 *
 *	Created By      : Anil Kumar on ...(in month of Aug 2001)
 *	Last Modified   : 09/Aug/2001
 *	Comment         : ASSERT definition
 *	EMail           : aksaharan@yahoo.com
 */

#ifndef _CUnit_h_
#define _CUnit_h_

#include <PalmOS.h>
#include "Errno.h"
#include "segments.h"
	
/* 
 * 	This is including the null character for termination. In effect it comes out
 * 	to be 255 characters.
 */
#define MAX_TEST_NAME_LENGTH	256
#define MAX_GROUP_NAME_LENGTH	256 

/*
 * 	Global type Definitions to be used for boolean operators
 */

#ifndef BOOL
	#define BOOL 	int
#endif

#ifndef FALSE
	#define FALSE	(int)0
#endif

#ifndef TRUE
	#define TRUE	(int)~FALSE
#endif

extern void assertTrueImplementation(char strMessage[], char strCondition[], 
  char strFile[], unsigned int uiLine) FRAMEWORK;

extern void assertInt8EqualImplementation(char strMessage[], Int8 exp, 
  Int8 act, char strFile[], unsigned int uiLine, unsigned int u) FRAMEWORK;

extern void assertInt16EqualImplementation(char strMessage[], Int16 exp, 
  Int16 act, char strFile[], unsigned int uiLine, unsigned int u) FRAMEWORK;

extern void assertInt32EqualImplementation(char strMessage[], Int32 exp, 
  Int32 act, char strFile[], unsigned int uiLine, unsigned int u) FRAMEWORK;

extern void assertStrEqualImplementation(char strMessage[], char strExp[], 
  char strAct[], char strFile[], unsigned int uiLine) FRAMEWORK;


#undef ASSERT
#define FAIL() { assertTrueImplementation("Generic fail", 0, __FILE__, __LINE__); return ; }

#define ASSERT(cond) if (0 == (int)(cond)) { assertTrueImplementation(0,"Condition should be true: "#cond, __FILE__, __LINE__); return; }

#define ASSERT_MSG(msg,cond) if (0 == (int)(cond)) { assertTrueImplementation(msg,"Condition should be true: "#cond, __FILE__, __LINE__); return; }

#define ASSERT_INT8_EQUAL(exp,act) if (!((exp) == (act))) { assertInt8EqualImplementation(0, (exp), (act), __FILE__, __LINE__,0); return; }

#define ASSERT_INT8_EQUAL_MSG(msg,exp,act) if (!((exp) == (act))) { assertInt8EqualImplementation(msg, (exp), (act), __FILE__, __LINE__,0); return; }

#define ASSERT_UINT8_EQUAL(exp,act) if (!((exp) == (act))) { assertInt8EqualImplementation(0, (exp), (act), __FILE__, __LINE__,1); return; }

#define ASSERT_UINT8_EQUAL_MSG(msg,exp,act) if (!((exp) == (act))) { assertInt8EqualImplementation(msg, (exp), (act), __FILE__, __LINE__,1); return; }

#define ASSERT_INT16_EQUAL(exp,act) if (!((exp) == (act))) { assertInt16EqualImplementation(0, (exp), (act), __FILE__, __LINE__,0); return; }

#define ASSERT_INT16_EQUAL_MSG(msg,exp,act) if (!((exp) == (act))) { assertInt16EqualImplementation(msg, (exp), (act), __FILE__, __LINE__,0); return; }

#define ASSERT_UINT16_EQUAL(exp,act) if (!((exp) == (act))) { assertInt16EqualImplementation(0, (exp), (act), __FILE__, __LINE__,1); return; }

#define ASSERT_UINT16_EQUAL_MSG(msg,exp,act) if (!((exp) == (act))) { assertInt16EqualImplementation(msg, (exp), (act), __FILE__, __LINE__,1); return; }

#define ASSERT_INT32_EQUAL(exp,act) if (!((exp) == (act))) { assertInt32EqualImplementation(0, (exp), (act), __FILE__, __LINE__,0); return; }

#define ASSERT_INT32_EQUAL_MSG(msg,exp,act) if (!((exp) == (act))) { assertInt32EqualImplementation(msg, (exp), (act), __FILE__, __LINE__,0); return; }

#define ASSERT_UINT32_EQUAL(exp,act) if (!((exp) == (act))) { assertInt32EqualImplementation(0, (exp), (act), __FILE__, __LINE__,1); return; }

#define ASSERT_UINT32_EQUAL_MSG(msg,exp,act) if (!((exp) == (act))) { assertInt32EqualImplementation(msg, (exp), (act), __FILE__, __LINE__,1); return; }

#define ASSERT_STR_EQUAL(exp,act) if (StrCompare((exp),(act))) { assertStrEqualImplementation(0, (exp), (act), __FILE__, __LINE__); return; }

#define ASSERT_STR_EQUAL_MSG(msg,exp,act) if (StrCompare((exp),(act))) { assertStrEqualImplementation(msg, (exp), (act), __FILE__, __LINE__); return; }




#define FAIL_GOTOERR() { assertTrueImplementation("Generic fail", 0, __FILE__, __LINE__); goto ERR; }

#define ASSERT_GOTOERR(cond) if (0 == (int)(cond)) { assertTrueImplementation(0,"Condition should be true: "#cond, __FILE__, __LINE__); goto ERR; }

#define ASSERT_MSG_GOTOERR(msg,cond) if (0 == (int)(cond)) { assertTrueImplementation(msg,"Condition should be true: "#cond, __FILE__, __LINE__); goto ERR; }

#define ASSERT_INT8_EQUAL_GOTOERR(exp,act) if (!((exp) == (act))) { assertInt8EqualImplementation(0, (exp), (act), __FILE__, __LINE__,0); goto ERR; }

#define ASSERT_INT8_EQUAL_MSG_GOTOERR(msg,exp,act) if (!((exp) == (act))) { assertInt8EqualImplementation(msg, (exp), (act), __FILE__, __LINE__,0); goto ERR; }

#define ASSERT_UINT8_EQUAL_GOTOERR(exp,act) if (!((exp) == (act))) { assertInt8EqualImplementation(0, (exp), (act), __FILE__, __LINE__,1); goto ERR; }

#define ASSERT_UINT8_EQUAL_MSG_GOTOERR(msg,exp,act) if (!((exp) == (act))) { assertInt8EqualImplementation(msg, (exp), (act), __FILE__, __LINE__,1); goto ERR; }

#define ASSERT_INT16_EQUAL_GOTOERR(exp,act) if (!((exp) == (act))) { assertInt16EqualImplementation(0, (exp), (act), __FILE__, __LINE__,0); goto ERR; }

#define ASSERT_INT16_EQUAL_MSG_GOTOERR(msg,exp,act) if (!((exp) == (act))) { assertInt16EqualImplementation(msg, (exp), (act), __FILE__, __LINE__,0); goto ERR; }

#define ASSERT_UINT16_EQUAL_GOTOERR(exp,act) if (!((exp) == (act))) { assertInt16EqualImplementation(0, (exp), (act), __FILE__, __LINE__,1); goto ERR; }

#define ASSERT_UINT16_EQUAL_MSG_GOTOERR(msg,exp,act) if (!((exp) == (act))) { assertInt16EqualImplementation(msg, (exp), (act), __FILE__, __LINE__,1); goto ERR; }

#define ASSERT_INT32_EQUAL_GOTOERR(exp,act) if (!((exp) == (act))) { assertInt32EqualImplementation(0, (exp), (act), __FILE__, __LINE__,0); goto ERR; }

#define ASSERT_INT32_EQUAL_MSG_GOTOERR(msg,exp,act) if (!((exp) == (act))) { assertInt32EqualImplementation(msg, (exp), (act), __FILE__, __LINE__,0); goto ERR; }

#define ASSERT_UINT32_EQUAL_GOTOERR(exp,act) if (!((exp) == (act))) { assertInt32EqualImplementation(0, (exp), (act), __FILE__, __LINE__,1); goto ERR; }

#define ASSERT_UINT32_EQUAL_MSG_GOTOERR(msg,exp,act) if (!((exp) == (act))) { assertInt32EqualImplementation(msg, (exp), (act), __FILE__, __LINE__,1); goto ERR; }

#define ASSERT_STR_EQUAL_GOTOERR(exp,act) if (StrCompare((exp),(act))) { assertStrEqualImplementation(0, (exp), (act), __FILE__, __LINE__); goto ERR; }

#define ASSERT_STR_EQUAL_MSG_GOTOERR(msg,exp,act) if (StrCompare((exp),(act))) { assertStrEqualImplementation(msg, (exp), (act), __FILE__, __LINE__); goto ERR; }

#endif  /*  _CUnit_h_  */
