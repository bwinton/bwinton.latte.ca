#!/usr/bin/python

# Set up the path.
import sys
import urllib
import vim

instance = "http://reviews.visophyte.org"

def fetchReview(review):
  url = "%s/r/emacsexport/%s/" % (instance, review)
  # Open the url.
  data = urllib.urlopen(url).readlines()
  return data

def viewReview(review):
  data = fetchReview(review)
  vim.command("tabnew")
  current = vim.current.buffer
  current[:] = data
  vim.command("set ft=reviewboard")
  vim.command("%foldopen!")

# run it as :py reviewboard.viewReview(72)
